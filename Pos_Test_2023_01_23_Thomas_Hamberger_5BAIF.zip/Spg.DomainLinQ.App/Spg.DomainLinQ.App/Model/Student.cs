﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    /// <summary>
    /// * RegistrationNumber
    /// * FirstName
    /// * LastName
    /// * EMail
    /// * Address
    /// * PhoneNumber
    /// * AccountName = [Die ersten 5 Stellen des LastName + RegistrationNumber]
    /// * Gender
    /// * Guid
    /// (4P)s
    /// </summary>
    public class Student : EntityBase
    {
        public int RegistrationNumber { get; set; }
        public string Firstname { get; set; } = string.Empty;
        public string Lastname { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public Address? Address { get; set; }
        public PhoneNumber? Number { get; set; }
        public string? AccountName { get; set; }
        public Genders Gender  { get; set; }
        public Guid Guid { get; set; }

        protected List<Student> Students = new();
        public Student(
            int registrationNumber, 
            string firstname, 
            string lastname, 
            string email, 
            Address? address, 
            PhoneNumber? number, 
            string? accountName, 
            Genders gender, 
            Guid guid, 
            List<Subject> subjects)
        {
            RegistrationNumber = registrationNumber;
            Firstname = firstname;
            Lastname = lastname;
            Email = email;
            Address = address;
            Number = number;
            AccountName = accountName;
            Gender = gender;
            Guid = guid;
            _subjects = subjects;
        }

        private List<Subject> _subjects = new();

        public void AddSubjects(List<Subject> subjects)
        {
            _subjects.AddRange(subjects);
        }
    }
}
