﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    // Gender als Enumeration [NA, FEMALE, MALE]
    // TODO: Implementation
    // (2P)

    public enum Genders
    {
        MALE = 0,
        FEMALE = 1,
        NA = 2
    }
}
