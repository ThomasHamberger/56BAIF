﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    /// <summary>
    /// * Name
    /// * Department [Die ersten 3 Zeichen von Name]
    /// * Guid
    /// (4P)
    /// </summary>
    public class SchoolClass : EntityBase
    {
        protected SchoolClass() { }
        public string Name { get; set; }
        public string Department { get; set; }
        public Guid Guid { get; set; }
        public SchoolClass(
            string name, 
            string department, 
            Guid guid,
            List<Teacher> teachers
            )
        {
            Name = name;
            Department = department;
            Guid = guid;
            teachers = teachers;
        }

        
        private List<Subject> _subjects = new();

        public void AddSubject(Subject subject)
        {
            _subjects.Add(subject);
        }

    }
}
