﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    /// <summary>
    /// * Date (?)
    /// * Lesson (int?)
    /// * Created
    /// * Guid
    /// * Grade (Note 1-5)
    /// (4P)
    /// </summary>
    public class Exam : EntityBase
    {
        public DateTime? Date { get; set; }
        public string Lesson { get; set; } 
        public Guid Guid { get; set; }
        public int Grade { get; set; }
        public Exam(
            DateTime date,
            string lesson,
            Guid guid,
            int grade,
            List<Subject> subjects) 
        {
            Date = date;
            Lesson = lesson;
            Guid = guid;
            Grade = grade;
            _subjects = subjects;
        }

        private List<Subject> _subjects = new();

        public void AddSubject(Subject subject)
        {
            _subjects.Add(subject);
        }
    }
}
