﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    /// <summary>
    /// * FirstName
    /// * LastName
    /// * EMail
    /// * Address
    /// * Gender
    /// * Guid
    /// (4P)
    /// </summary>
    public class Teacher : EntityBase
    {
        public string? Firstname { get; set; }
        public string? Lastname { get; set; } = null;
        public string Email { get; set; } = string.Empty;
        public Genders Gender { get; set; }
        public Guid Guid { get; set; }
        public Address? Address { get; set; }
      

        private readonly List<Teacher> teachers = new();
        public Teacher(
            string? firstname,
            string? lastname,
            string email,
            Address? address,
            Genders gender,
            Guid guid,
            List<Subject> subjects)
        {
            Firstname = firstname;
            Lastname = lastname;
            Email = email;
            Address = address;
            Gender = gender;
            Guid = guid;
            _subjects = subjects;
        }



        private List<Subject> _subjects = new();

        public void AddSubject(Subject subject)
        {
            _subjects.Add(subject);
        }
    }
}
