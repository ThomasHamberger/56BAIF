﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    public class Address
    {
        public string? StreetName { get; set; }
        public string Zip { get; set; }
        public string City { get; set; }
        public Address(
            string streetName,
            string zip,
            string city)
        {
            StreetName = streetName;
            Zip = zip;
            City = city;
        }
    }

    /// <summary>
    /// * Street
    /// * Zip
    /// * City
    /// (2P)
    /// </summary>
  
}
